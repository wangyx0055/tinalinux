#!/bin/sh

export MG_CFG_PATH=$prefix/myetc/bootstrap

bootstrap
