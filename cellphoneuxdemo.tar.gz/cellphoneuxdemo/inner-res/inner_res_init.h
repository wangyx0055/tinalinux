
#ifdef _MGINCORE_RES
#ifdef __cplusplus
extern "C" {
#endif

extern int CellPhoneInitInnerResource (void);
extern int CellPhoneSetMiniGUICFG (void);

#ifdef __cplusplus
}
#endif
#endif

