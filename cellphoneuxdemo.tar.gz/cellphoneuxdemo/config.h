#ifndef CONFIG_H
#define CONFIG_H

/* Define for X86 version */
#define __ARCH_X86__         1

/* Define for s3c6410 version */
/* #undef __ARCH_S3C6410__ */

#endif  /* CONFIG_H */
