.. cmake-module:: ../../Modules/GenerateExportHeader.cmake
